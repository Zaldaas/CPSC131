# Homework 1 - Git Practice Submission

My submission for CPSC 131, Section 02, Homework 1 - Git Practice

# My Information

* Name: Zeid Aldaas
* CWID: 885097022
* Email: zaldaas@csu.fullerton.edu
